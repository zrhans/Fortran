#! /bin/csh -f
# test.sh (for sgi machine)
f77 -c -static crclib.f
# CHAP2
echo ' COMPILING AND RUNING PROGRAMS IN CHAP2'
f77 deriv.f        crclib.o
a.out > deriv.ggd || exit
f77 jacobian.f     crclib.o  
a.out > jacobian.ggd || exit
f77 laplacian.f    crclib.o
a.out > laplacian.ggd || exit
 
# CHAP3 
echo ' COMPILING AND RUNING PROGRAMS IN CHAP3'
f77 kinematic.f    crclib.o
a.out > kinematic.ggd || exit
f77 q2glw.f        crclib.o
a.out > q2glw.ggd || exit
    
# CHAP4
echo ' COMPILING AND RUNING PROGRAMS IN CHAP4'

f77 geopotential.f crclib.o
a.out > geopotential.ggd || exit
f77 stream.f       crclib.o
a.out > stream.ggd || exit
    
# CHAP5
echo ' COMPILING AND RUNING PROGRAMS IN CHAP5'

f77 cressman.f     crclib.o
a.out > cressman.ggd || exit
f77 barnes.f       crclib.o 
a.out > barnes.ggd || exit
    
# CHAP6
echo ' COMPILING AND RUNING PROGRAMS IN CHAP6'

f77 convert.f      crclib.o  
a.out > convert.ggd || exit
f77 lcl.f          crclib.o    
a.out > lcl.ggd || exit
f77 adjust.f       crclib.o 
a.out > adjust.ggd || exit
f77 nicker.f       crclib.o 
a.out > nicker.ggd || exit
f77 splun.f        crclib.o
a.out > splun.ggd || exit
    
# CHAP7
echo ' COMPILING AND RUNING PROGRAMS IN CHAP7'

f77 kuo.f          crclib.o
a.out > kuo.ggd || exit
    
# CHAP8
echo ' COMPILING AND RUNING PROGRAMS IN CHAP8'

f77 simflx.f       crclib.o
a.out > simflx.ggd || exit
     
# CHAP9
echo ' COMPILING AND RUNING PROGRAMS IN CHAP9'

f77 -static radia.f     crclib.f
a.out > radia.ggd || exit

# CHAP10
echo ' COMPILING AND RUNING PROGRAMS IN CHAP10'

f77 infield.f     crclib.o
a.out > infield.ggd || exit
f77 baro.f        crclib.o
a.out > baro.ggd || exit
f77 barout.f      crclib.o
a.out > barout.ggd || exit

# CHAP11
echo ' COMPILING AND RUNING PROGRAMS IN CHAP11'
# baro.f and silepe.f use thesame subroutines
# which have different parameters . therefore
# we are giving silepe.f and its infield.f
# as satnd alone versions .
#
f77 -static infield_silepe.f 
a.out > infields.ggd || exit
f77    silepe.f        
a.out > silepe.ggd || exit

# CHAP12
echo ' COMPILING AND RUNING PROGRAMS IN CHAP12'

f77 ssmi.f        crclib.o
a.out > ssmi.ggd || exit

# CHAP13
echo ' COMPILING AND RUNING PROGRAMS IN CHAP13'

f77 diagnos.f      crclib.o
a.out > diagnos.ggd || exit
f77 traject.f      crclib.o
a.out > traject.ggd || exit
